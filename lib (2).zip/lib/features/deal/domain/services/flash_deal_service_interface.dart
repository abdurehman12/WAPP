
abstract class FlashDealServiceInterface {

  Future<dynamic> getFlashDeal();
  Future<dynamic> get(String productID);

}