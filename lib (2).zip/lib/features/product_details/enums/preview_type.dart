enum PreviewType {
  video,
  audio,
  pdf,
  image,
  others
}