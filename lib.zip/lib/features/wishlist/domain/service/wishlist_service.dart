class WishListService{

}