
abstract class WishlistServiceInterface {

}