
abstract class DealServiceInterface {

}