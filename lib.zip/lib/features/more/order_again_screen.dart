// import 'package:flutter/material.dart';
// import 'package:flutter_sixvalley_ecommerce/features/auth/controllers/auth_controller.dart';
// import 'package:flutter_sixvalley_ecommerce/features/banner/controllers/banner_controller.dart';
// import 'package:flutter_sixvalley_ecommerce/features/banner/widgets/single_banner.dart';
// import 'package:flutter_sixvalley_ecommerce/features/home/widget/aster_theme/order_again_view.dart';
// import 'package:flutter_sixvalley_ecommerce/features/more/more_screen.dart';
// import 'package:flutter_sixvalley_ecommerce/features/order/provider/order_provider.dart';
// import 'package:flutter_sixvalley_ecommerce/utill/dimensions.dart';
// import 'package:provider/provider.dart';

// class OrderAgainScreen extends StatelessWidget {
//   const OrderAgainScreen({super.key});

//   @override
//  Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         // automaticallyImplyLeading: false,
//         leading: IconButton(
//           onPressed: (){
//             Navigator.push(
//         context, MaterialPageRoute(builder: (_) => MoreScreen())
//         );},
//           icon: Icon(Icons.arrow_left))
//       ),
//       body: OrderAgainView()
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:flutter_sixvalley_ecommerce/features/auth/controllers/auth_controller.dart';
// import 'package:flutter_sixvalley_ecommerce/features/banner/controllers/banner_controller.dart';
// import 'package:flutter_sixvalley_ecommerce/features/banner/widgets/single_banner.dart';
// import 'package:flutter_sixvalley_ecommerce/features/home/widget/aster_theme/order_again_view.dart';
// import 'package:flutter_sixvalley_ecommerce/features/more/more_screen.dart';
// import 'package:flutter_sixvalley_ecommerce/features/order/provider/order_provider.dart';
// import 'package:flutter_sixvalley_ecommerce/localization/language_constrants.dart';
// import 'package:flutter_sixvalley_ecommerce/utill/custom_themes.dart';
// import 'package:flutter_sixvalley_ecommerce/utill/dimensions.dart';
// import 'package:provider/provider.dart';

// class OrderAgainScreen extends StatelessWidget {
//   const OrderAgainScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         leading: IconButton(
//           onPressed: () {
//             Navigator.push(
//               context, MaterialPageRoute(builder: (_) => MoreScreen()),
//             );
//           },
//           icon: Icon(Icons.arrow_left),
//         ),
//       ),
//       body: Consumer<OrderProvider>(
//         builder: (context, orderProvider, _) {
//           if (orderProvider.isLoading) {
//             // Show a loading indicator while data is loading
//             return Center(child: CircularProgressIndicator());
//           }

//           return Container(
//             width: MediaQuery.of(context).size.width,
//             padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
//             decoration: BoxDecoration(
//               color: Theme.of(context).primaryColor.withOpacity(0.125),
//               borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//             ),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 Text(
//                   getTranslated('order_again', context)!,
//                   style: robotoBold.copyWith(
//                     fontSize: Dimensions.fontSizeLarge,
//                     color: Theme.of(context).primaryColor,
//                   ),
//                 ),
//                 const SizedBox(height: Dimensions.paddingSizeSmall),
//                 Text(
//                   getTranslated('want_to_order_your_usuals_just_reorder_from_your_previous_orders', context)!,
//                   style: textRegular.copyWith(fontSize: Dimensions.fontSizeSmall),
//                 ),
//                 const SizedBox(height: Dimensions.paddingSizeSmall),
//                 if (orderProvider.deliveredOrderModel != null &&
//                     orderProvider.deliveredOrderModel!.orders != null &&
//                     orderProvider.deliveredOrderModel!.orders!.isNotEmpty)
//                   Expanded(
//                     child: ListView.builder(
//                       itemCount: orderProvider.deliveredOrderModel!.orders!.length > 2
//                           ? 2
//                           : orderProvider.deliveredOrderModel!.orders!.length,
//                       shrinkWrap: true,
//                       padding: EdgeInsets.zero,
//                       physics: const NeverScrollableScrollPhysics(),
//                       itemBuilder: (context, index) {
//                         return OrderAgainCard(
//                           orders: orderProvider.deliveredOrderModel!.orders![index],
//                         );
//                       },
//                     ),
//                   )
//                 else
//                   Center(child: Text('No orders available.')),
//               ],
//             ),
//           );
//         },
//       ),
//     );
//   }
// }


// import 'package:flutter/material.dart';
// import 'package:flutter_sixvalley_ecommerce/features/home/widget/aster_theme/order_again_view.dart';
// import 'package:flutter_sixvalley_ecommerce/features/more/more_screen.dart';
// import 'package:flutter_sixvalley_ecommerce/features/order/provider/order_provider.dart';
// import 'package:flutter_sixvalley_ecommerce/localization/language_constrants.dart';
// import 'package:flutter_sixvalley_ecommerce/utill/custom_themes.dart';
// import 'package:flutter_sixvalley_ecommerce/utill/dimensions.dart';
// import 'package:provider/provider.dart';

// class OrderAgainScreen extends StatelessWidget {
//   const OrderAgainScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         leading: IconButton(
//           onPressed: () {
//             Navigator.push(
//               context, MaterialPageRoute(builder: (_) => MoreScreen()),
//             );
//           },
//           icon: Icon(Icons.arrow_left),
//         ),
//       ),
//       body: Consumer<OrderProvider>(
//         builder: (context, orderProvider, _) {
//           // Check if data is still loading
//           if (orderProvider.isLoading) {
//             return Center(child: CircularProgressIndicator());
//           }

//           // Check if orders are available after loading is complete
//           if (orderProvider.deliveredOrderModel != null &&
//               orderProvider.deliveredOrderModel!.orders != null &&
//               orderProvider.deliveredOrderModel!.orders!.isNotEmpty) {
//             return Container(
//               width: MediaQuery.of(context).size.width,
//               padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
//               decoration: BoxDecoration(
//                 color: Theme.of(context).primaryColor.withOpacity(0.125),
//                 borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//               ),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Text(
//                     getTranslated('order_again', context)!,
//                     style: robotoBold.copyWith(
//                       fontSize: Dimensions.fontSizeLarge,
//                       color: Theme.of(context).primaryColor,
//                     ),
//                   ),
//                   const SizedBox(height: Dimensions.paddingSizeSmall),
//                   Text(
//                     getTranslated('want_to_order_your_usuals_just_reorder_from_your_previous_orders', context)!,
//                     style: textRegular.copyWith(fontSize: Dimensions.fontSizeSmall),
//                   ),
//                   const SizedBox(height: Dimensions.paddingSizeSmall),
//                   Expanded(
//                     child: ListView.builder(
//                       itemCount: orderProvider.deliveredOrderModel!.orders!.length > 2
//                           ? 2
//                           : orderProvider.deliveredOrderModel!.orders!.length,
//                       shrinkWrap: true,
//                       padding: EdgeInsets.zero,
//                       physics: const NeverScrollableScrollPhysics(),
//                       itemBuilder: (context, index) {
//                         return OrderAgainCard(
//                           orders: orderProvider.deliveredOrderModel!.orders![index],
//                         );
//                       },
//                     ),
//                   ),
//                 ],
//               ),
//             );
//           } else {
//             // Show a message if no orders are available
//             return Center(
//               child: Text(
//                 getTranslated('no_orders_available', context) ?? 'No orders available.',
//                 style: textRegular.copyWith(fontSize: Dimensions.fontSizeDefault),
//               ),
//             );
//           }
//         },
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';
import 'package:flutter_sixvalley_ecommerce/features/home/widget/aster_theme/order_again_view.dart';
import 'package:flutter_sixvalley_ecommerce/features/more/more_screen.dart';
import 'package:flutter_sixvalley_ecommerce/features/order/provider/order_provider.dart';
import 'package:flutter_sixvalley_ecommerce/localization/language_constrants.dart';
import 'package:flutter_sixvalley_ecommerce/utill/custom_themes.dart';
import 'package:flutter_sixvalley_ecommerce/utill/dimensions.dart';
import 'package:provider/provider.dart';

class OrderAgainScreen extends StatefulWidget {
  const OrderAgainScreen({super.key});

  @override
  _OrderAgainScreenState createState() => _OrderAgainScreenState();
}

class _OrderAgainScreenState extends State<OrderAgainScreen> {
  bool _isLoading = true;
  bool _hasOrders = false;

  @override
  void initState() {
    super.initState();
    _loadOrders();
  }

  Future<void> _loadOrders() async {
    final orderProvider = Provider.of<OrderProvider>(context, listen: false);

    try {
      await orderProvider.getOrderList(1, 'delivered'); // Adjust parameters as needed
      setState(() {
        
        _hasOrders = orderProvider.deliveredOrderModel != null &&
            orderProvider.deliveredOrderModel!.orders != null &&
            orderProvider.deliveredOrderModel!.orders!.isNotEmpty;
            _isLoading = false;
      });
    } catch (error) {
      // Handle any errors if needed
      setState(() {
        _isLoading = false;
        _hasOrders = false; // Set to false if there's an error
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final orderProvider = Provider.of<OrderProvider>(context); // Access provider here

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.push(
              context, MaterialPageRoute(builder: (_) => MoreScreen()),
            );
          },
          icon: Icon(Icons.arrow_left),
        ),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _hasOrders
              ? Container(
                  width: MediaQuery.of(context).size.width,
                  padding: const EdgeInsets.all(Dimensions.paddingSizeLarge),
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor.withOpacity(0.125),
                    borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        getTranslated('order_again', context)!,
                        style: robotoBold.copyWith(
                          fontSize: Dimensions.fontSizeLarge,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                      const SizedBox(height: Dimensions.paddingSizeSmall),
                      Text(
                        getTranslated('want_to_order_your_usuals_just_reorder_from_your_previous_orders', context)!,
                        style: textRegular.copyWith(fontSize: Dimensions.fontSizeSmall),
                      ),
                      const SizedBox(height: Dimensions.paddingSizeSmall),
                      Expanded(
                        child: ListView.builder(
                          itemCount: orderProvider.deliveredOrderModel!.orders!.length > 2
                              ? 2
                              : orderProvider.deliveredOrderModel!.orders!.length,
                          shrinkWrap: true,
                          padding: EdgeInsets.zero,
                          physics: const NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) {
                            return OrderAgainCard(
                              orders: orderProvider.deliveredOrderModel!.orders![index],
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                )
              : Center(
                  child: 
                  Text(
                    getTranslated('no_orders_available', context) ?? 'No orders available.',
                    style: textRegular.copyWith(fontSize: Dimensions.fontSizeDefault),
                  ),
                ),
    );
  }
}
