
class ChatServiceInterface {

}