abstract class SupportTicketServiceInterface{

}