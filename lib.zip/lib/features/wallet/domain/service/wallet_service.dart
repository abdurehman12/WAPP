class WalletService{

}