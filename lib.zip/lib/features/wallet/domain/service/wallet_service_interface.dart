
abstract class WalletServiceInterface {

}