
abstract class CategoryServiceInterface {

}