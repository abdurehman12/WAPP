import 'package:flutter/material.dart';
import 'package:flutter_sixvalley_ecommerce/basewidget/product_widget.dart';
import 'package:flutter_sixvalley_ecommerce/features/category/domain/model/category_model.dart';
import 'package:flutter_sixvalley_ecommerce/features/product/provider/product_provider.dart';
import 'package:flutter_sixvalley_ecommerce/localization/language_constrants.dart';
import 'package:flutter_sixvalley_ecommerce/features/category/controllers/category_controller.dart';
import 'package:flutter_sixvalley_ecommerce/features/splash/provider/splash_provider.dart';
import 'package:flutter_sixvalley_ecommerce/theme/provider/theme_provider.dart';
import 'package:flutter_sixvalley_ecommerce/utill/color_resources.dart';
import 'package:flutter_sixvalley_ecommerce/utill/custom_themes.dart';
import 'package:flutter_sixvalley_ecommerce/utill/dimensions.dart';
import 'package:flutter_sixvalley_ecommerce/utill/images.dart';
import 'package:flutter_sixvalley_ecommerce/basewidget/custom_app_bar.dart';
import 'package:flutter_sixvalley_ecommerce/features/product/view/brand_and_category_product_screen.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:provider/provider.dart';

class HomeCategoryScreen extends StatefulWidget {
  const HomeCategoryScreen({super.key});

  @override
  _HomeCategoryScreenState createState() => _HomeCategoryScreenState();
}

class _HomeCategoryScreenState extends State<HomeCategoryScreen> {
  Future<void>? _fetchProductsFuture;
  bool isLoadingSubcategories = false;
  bool isDataAvailable = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: getTranslated('CATEGORY', context),
        isBackButtonExist: false,
      ),
      body: Consumer<CategoryController>(
        builder: (context, categoryProvider, child) {
          if (categoryProvider.categoryList == null ||
              categoryProvider.categoryList!.isEmpty) {
            return Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(
                    Theme.of(context).primaryColor),
              ),
            );
          }

          return Column(
            children: [
              // Categories in Rows
              SingleChildScrollView(
                padding:
                    const EdgeInsets.all(Dimensions.paddingSizeSmall),
                child: Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: List.generate(
                    
                    categoryProvider.categoryList!.length,
                    (index) {
                      CategoryModel category =
                          categoryProvider.categoryList![index];
                      return InkWell(
                        onTap: () {
                          categoryProvider.changeSelectedIndex(index);
                          setState(() {
                            isLoadingSubcategories = true;
                            isDataAvailable = true;
                            _fetchProductsFuture = _fetchProducts(
                              categoryProvider,
                              categoryProvider.categoryList![index],
                            );
                          });
                        },
                        child: CategoryItem(
                          title: category.name,
                          icon: category.icon,
                          isSelected: categoryProvider
                                  .categorySelectedIndex == index,
                        ),
                      );
                    },
                  ),
                ),
            
              ),

              // Subcategories List
              Expanded(
                child: isLoadingSubcategories
                    ? Center(
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(
                              Theme.of(context).primaryColor),
                        ),
                      )
                    : SingleChildScrollView(
                      child: Container(
                        height: 300,
                        child: FutureBuilder<void>(
                            future: _fetchProductsFuture,
                            builder: (context, snapshot) {
                              if (snapshot.connectionState == ConnectionState.waiting) {
                                return Center(
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                        Theme.of(context).primaryColor),
                                  ),
                                );
                              } else if (snapshot.hasError) {
                                return Center(
                                  child: Text(
                                    getTranslated('error_occurred', context) ??
                                        'An error occurred',
                                    style: titilliumSemiBold.copyWith(
                                        fontSize: Dimensions.fontSizeDefault),
                                  ),
                                );
                              } else {
                                final productProvider =
                                    Provider.of<ProductProvider>(context);
                                if (productProvider
                                    .brandOrCategoryProductList.isEmpty) {
                                  return Center(
                                    child: Column(
                                      // mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                         Image.asset(Images.no_data_found, width: 100,color: Provider.of<ThemeProvider>(context, listen: false).darkTheme ?
                                      Colors.white : Theme.of(context).primaryColor,),
                                        Text(
                                          getTranslated('no_product_found', context) ??
                                              'No Product Found',
                                          style: titilliumSemiBold.copyWith(
                                              fontSize: Dimensions.fontSizeDefault),
                                        ),
                                      ],
                                    ),
                                  );
                                } else {
                                  return Column(
                                    children: [
                                      // "All Products" Button
                                      Ink(
                                        color: Theme.of(context).highlightColor,
                                        child: ListTile(
                                          title: Text(
                                              getTranslated('all_products', context)!,
                                              style: titilliumSemiBold,
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis),
                                          trailing: const Icon(Icons.navigate_next),
                                          onTap: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (_) => BrandAndCategoryProductScreen(
                                                  isBrand: false,
                                                  id: categoryProvider
                                                      .categoryList![
                                                          categoryProvider
                                                              .categorySelectedIndex!]
                                                      .id
                                                      .toString(),
                                                  name: categoryProvider
                                                      .categoryList![
                                                          categoryProvider
                                                              .categorySelectedIndex!]
                                                      .name,
                                                ),
                                              ),
                                            );
                                          },
                                        ),
                                      ),
                                      Expanded(
                                        child: MasonryGridView.count(
                                          crossAxisCount: 2,
                                          itemCount: productProvider
                                              .brandOrCategoryProductList.length,
                                          shrinkWrap: true,
                                          physics:
                                              const NeverScrollableScrollPhysics(),
                                          itemBuilder:
                                              (BuildContext context, int index) {
                                            return ProductWidget(
                                                productModel: productProvider
                                                        .brandOrCategoryProductList[
                                                    index]);
                                          },
                                        ),
                                      ),
                                    ],
                                  );
                                }
                              }
                            },
                          ),
                      ),
                    ),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _fetchProducts(
      CategoryController categoryProvider, CategoryModel category) async {
    await Provider.of<ProductProvider>(context, listen: false)
        .initBrandOrCategoryProductList(
      false,
      category.id.toString(),
      context,
    );

    setState(() {
      isLoadingSubcategories = false;
      isDataAvailable = true;
    });
  }
}

// class CategoryItem extends StatelessWidget {
//   final String? title;
//   final String? icon;
//   final bool isSelected;
//   const CategoryItem(
//       {super.key,
//       required this.title,
//       required this.icon,
//       required this.isSelected});

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       width: 140,
//       height: 50,
//       margin: const EdgeInsets.symmetric(
//           vertical: Dimensions.paddingSizeExtraSmall, horizontal: 2),
//       decoration: BoxDecoration(
//         borderRadius: BorderRadius.circular(10),
//         color: isSelected ? ColorResources.getPrimary(context) : null,
//         border: Border.all(
//             width: 1, color: isSelected ? Colors.transparent : Colors.grey),
//       ),
//       child: Center(
//         child: Row(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Container(
//               height: 30,
//               width: 30,
//               decoration: BoxDecoration(
//                   border: Border.all(
//                       width: 2,
//                       color: isSelected
//                           ? Theme.of(context).highlightColor
//                           : Theme.of(context).hintColor),
//                   borderRadius: BorderRadius.circular(10),
//                   color: Theme.of(context).canvasColor),
//               child: ClipRRect(
//                 borderRadius: BorderRadius.circular(10),
//                 child: FadeInImage.assetNetwork(
//                   placeholder: Images.placeholder,
//                   fit: BoxFit.cover,
//                   image:
//                       '${Provider.of<SplashProvider>(context, listen: false).baseUrls!.categoryImageUrl}/$icon',
//                   imageErrorBuilder: (c, o, s) =>
//                       Image.asset(Images.placeholder, fit: BoxFit.cover),
//                 ),
//               ),
//             ),
//             const SizedBox(width: 5),
//             Flexible(
//               child: Text(
//                 title!,
//                 style: titilliumRegular.copyWith(
//                     color: isSelected ? Colors.white : Colors.black),
//                 textAlign: TextAlign.center,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }


class CategoryItem extends StatelessWidget {
  final String? title;
  final String? icon;
  final bool isSelected;
  const CategoryItem({super.key, required this.title, required this.icon, required this.isSelected});

  @override
  Widget build(BuildContext context) {
    return 
    Container(
      width: 100,
      height: 100,
      margin: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeExtraSmall, horizontal: 2),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: isSelected ? ColorResources.getPrimary(context) : null,
      ),
      child: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          Container(
            height: 50,
            width: 50,
            decoration: BoxDecoration(
              border: Border.all(width: 2, color: isSelected ? Theme.of(context).highlightColor : Theme.of(context).hintColor),
              borderRadius: BorderRadius.circular(10),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: FadeInImage.assetNetwork(
                color: isSelected?Colors.white:null,
                placeholder: Images.placeholder, fit: BoxFit.cover,
                image: '${Provider.of<SplashProvider>(context,listen: false).baseUrls!.categoryImageUrl}/$icon',
                imageErrorBuilder: (c, o, s) => Image.asset(Images.placeholder, fit: BoxFit.cover),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeExtraSmall),
            child: Text(title!, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: titilliumSemiBold.copyWith(
              fontSize: Dimensions.fontSizeExtraSmall,
              color: isSelected ? Theme.of(context).highlightColor : Theme.of(context).hintColor,
            )),
          ),
        ]),
      ),
    );
  }
}