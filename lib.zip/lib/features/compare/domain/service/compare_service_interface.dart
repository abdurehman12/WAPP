
abstract class CompareServiceInterface{

}