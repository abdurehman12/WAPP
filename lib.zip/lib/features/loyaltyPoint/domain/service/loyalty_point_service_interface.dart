
class LoyaltyPointServiceInterface {

}