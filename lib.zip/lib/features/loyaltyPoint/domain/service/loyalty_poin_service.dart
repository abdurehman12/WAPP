class LoyaltyPointService{

}