abstract class CouponRepoInterface{

}