abstract class LocationRepoInterface{

}