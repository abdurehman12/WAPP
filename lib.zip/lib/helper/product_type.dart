enum ProductType {
  allProduct,
  latestProduct,
  sellerProduct,
  featuredProduct,
  topProduct,
  newArrival,
  bestSelling,
  discountedProduct,
  justForYou
}